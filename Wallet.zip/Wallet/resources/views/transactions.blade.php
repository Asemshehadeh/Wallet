@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div>
        <div class="card">
                <div class="card-header">{{ __('User Profile') }} / {{Auth::user()->name}}</div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <ul class="nav nav-pills nav-fill">
                        <li class="nav-item">
                            <a class="nav-link active" href="{{ url('/translist') }}">Wallet Transactions</a>
                            <div>                
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <table class="table">
                    <thead class="thead-dark">
                        <tr>                        
                        <th scope="col">Total ExpensesName</th>
                        <th scope="col">Total Income</th>
                        <th scope="col">Wallet balance</th>
                        </tr>
                    </thead>
                    <tbody>                    
                    <tr>                    
                    <td>{{ $total['total_expenses'] }}</td>
                    <td>{{ $total['total_income'] }}</td>
                    <td>Wallet</td>
                    </tr>                    
                    </tbody>
                    </table>
                    <table class="table">
                    <thead class="thead">
                        <tr>                        
                        <th scope="col">ID</th>
                        <th scope="col">Amount</th>
                        <th scope="col">Type</th>
                        <th scope="col">Date</th>
                        
                        </tr>
                    </thead>
                    <tbody>                    
                    <tr>                    
                    @foreach($all_trans as $all_tran)
                    <tr>
                    <td>{{$all_tran->tran_id}}</td>
                    <td>{{$all_tran->amount}}</td>
                    <td>{{$category_name[$all_tran->tran_id]['cat_name'] }}</td>
                    <td>{{$all_tran->created_at}}</td>                    
                    </tr>
                    @endforeach
                    </tr>                    
                    </tbody>
                    </table>

                </div>
            </div>
                        </li>                        
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('/home') }}">Back</a>
                        </li>
                        </ul>
                </div>
        </div>                
        </div>
    </div>
</div>
@endsection