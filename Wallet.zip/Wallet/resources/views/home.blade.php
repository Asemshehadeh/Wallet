@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div>

        @if ( Auth::user()->role_id == 1)
        <div>
                <div class="card-header">{{ __('Admin Profile') }} / {{Auth::user()->name}}</div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <table class="table">
                    <thead class="thead-dark">
                        <tr>                        
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Birthdate</th>
                        <th scope="col">Total Expenses</th>
                        <th scope="col">Total Income</th>
                        <th scope="col">Registered Date</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($users as $user)
                    <tr>
                    <td>{{$user->name}}</td>
                    <td>{{$user->email}}</td>
                    <td>{{$user->phone}}</td>
                    <td>{{$user->birthday}}</td>
                    <td>{{ $total[$user->id]['total_expenses'] }}</td>
                    <td>{{ $total[$user->id]['total_income'] }}</td>
                    <td>{{$user->created_at}}</td>
                    </tr>
                    @endforeach
                    </tbody>
                    </table>
                </div>
            </div>
        @else
        <div class="card">
                <div class="card-header">{{ __('User Profile') }} / {{Auth::user()->name}}</div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <ul class="nav nav-pills nav-fill">
                        <li class="nav-item">
                        <a class="nav-link" href="{{ url('/translist') }}">Wallet Transactions</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('/catlist') }}">Add Transaction</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('/category') }}">Create New Category</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('/chartjs') }}">Charts</a>
                        </li>
                        
                        </ul>
                </div>
        </div>
        @endif            
        </div>
    </div>
</div>
@endsection