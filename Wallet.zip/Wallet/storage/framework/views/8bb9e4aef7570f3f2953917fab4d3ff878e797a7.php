<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div>
        <div class="card">
                <div class="card-header"><?php echo e(__('User Profile')); ?> / <?php echo e(Auth::user()->name); ?></div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <ul class="nav nav-pills nav-fill">
                        <li class="nav-item">
                            <a class="nav-link active" href="<?php echo e(url('/category')); ?>">Create New Category</a>
                            <div>                
                    <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table">
                    <form action="submitcat" method="POST">
                        <?php echo csrf_field(); ?>

                        <tbody>                    
                    <tr>                    
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($categorie->cat_id); ?></td>
                    <td><?php echo e($categorie->cat_name); ?></td>
                    <td><?php echo e($categorie->cat_type); ?></td>
                    <td><?php echo e($categorie->created_at); ?></td>                    
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>                    
                    </tbody>

                        <input type="text" name="cat_name" placeholder="cat name" >
                        <br><br>

                        <label for="cars">Type:</label>
                        <select name="cat_type" id="cat_type">
                        <option value="Income">Income</option>
                        <option value="Expenses">Expenses</option>                        
                        </select>
                        <br><br>
                        <button type="submit">Submit</button>
                    </form>
                    </table>
                </div>
            </div>
                        </li>                        
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/home')); ?>">Back</a>
                        </li>
                        </ul>
                </div>
        </div>                
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Wallet/resources/views/categoryview.blade.php ENDPATH**/ ?>