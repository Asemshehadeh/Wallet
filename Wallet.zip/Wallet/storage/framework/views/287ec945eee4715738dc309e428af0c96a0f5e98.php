<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div>
        <div class="card">
                <div class="card-header"><?php echo e(__('User Profile')); ?> / <?php echo e(Auth::user()->name); ?></div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <ul class="nav nav-pills nav-fill">
                        <li class="nav-item">
                            <a class="nav-link active" href="<?php echo e(url('/form')); ?>">Add Transaction</a>
                            <div>                
                    <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table">
                            <form action="submit" method="POST">
                            <?php echo csrf_field(); ?>
                            <select name="cat_id">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($category->cat_id); ?> ><?php echo e($category->cat_name); ?></option>                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>                            
                            <br><br>
                            <input type="text" name="amount" placeholder="Amount" >
                            <br><br>
                            <button type="submit">Submite</button>
                        </form>
                    </table>
                </div>
            </div>
                        </li>                        
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/home')); ?>">Back</a>
                        </li>
                        </ul>
                </div>
        </div>                
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Wallet/resources/views/userview.blade.php ENDPATH**/ ?>