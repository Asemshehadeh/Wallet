<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div>
        <div class="card">
                <div class="card-header"><?php echo e(__('User Profile')); ?> / <?php echo e(Auth::user()->name); ?></div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <ul class="nav nav-pills nav-fill">
                        <li class="nav-item">
                            <a class="nav-link active" href="<?php echo e(url('/translist')); ?>">Wallet Transactions</a>
                            <div>                
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table">
                    <thead class="thead-dark">
                        <tr>                        
                        <th scope="col">Total ExpensesName</th>
                        <th scope="col">Total Income</th>
                        <th scope="col">Wallet balance</th>
                        </tr>
                    </thead>
                    <tbody>                    
                    <tr>                    
                    <td><?php echo e($total['total_expenses']); ?></td>
                    <td><?php echo e($total['total_income']); ?></td>
                    <td>Wallet</td>
                    </tr>                    
                    </tbody>
                    </table>
                    <table class="table">
                    <thead class="thead">
                        <tr>                        
                        <th scope="col">ID</th>
                        <th scope="col">Amount</th>
                        <th scope="col">Type</th>
                        <th scope="col">Date</th>
                        
                        </tr>
                    </thead>
                    <tbody>                    
                    <tr>                    
                    <?php $__currentLoopData = $all_trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_tran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($all_tran->tran_id); ?></td>
                    <td><?php echo e($all_tran->amount); ?></td>
                    <td><?php echo e($category_name[$all_tran->tran_id]['cat_name']); ?></td>
                    <td><?php echo e($all_tran->created_at); ?></td>                    
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>                    
                    </tbody>
                    </table>

                </div>
            </div>
                        </li>                        
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/home')); ?>">Back</a>
                        </li>
                        </ul>
                </div>
        </div>                
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Wallet/resources/views/transactions.blade.php ENDPATH**/ ?>