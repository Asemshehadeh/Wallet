<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div>

        <?php if( Auth::user()->role_id == 1): ?>
        <div>
                <div class="card-header"><?php echo e(__('Admin Profile')); ?> / <?php echo e(Auth::user()->name); ?></div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table">
                    <thead class="thead-dark">
                        <tr>                        
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Birthdate</th>
                        <th scope="col">Total Expenses</th>
                        <th scope="col">Total Income</th>
                        <th scope="col">Registered Date</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->birthday); ?></td>
                    <td><?php echo e($total[$user->id]['total_expenses']); ?></td>
                    <td><?php echo e($total[$user->id]['total_income']); ?></td>
                    <td><?php echo e($user->created_at); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
            </div>
        <?php else: ?>
        <div class="card">
                <div class="card-header"><?php echo e(__('User Profile')); ?> / <?php echo e(Auth::user()->name); ?></div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <ul class="nav nav-pills nav-fill">
                        <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/translist')); ?>">Wallet Transactions</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/catlist')); ?>">Add Transaction</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/category')); ?>">Create New Category</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/chartjs')); ?>">Charts</a>
                        </li>
                        
                        </ul>
                </div>
        </div>
        <?php endif; ?>            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/Wallet/resources/views/home.blade.php ENDPATH**/ ?>