<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_transactions', function (Blueprint $table) {
            $table->increments('tran_id');            
            $table->integer('cat_id_f')->unsigned();
            $table->integer('user_id_f')->unsigned();
            $table->integer('amount')->unsigned();
            $table->foreign('user_id_f')->references('id')->on('users');
            $table->foreign('cat_id_f')->references('cat_id')->on('categories');
            $table->index(['user_id_f', 'cat_id_f']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_transactions');
    }
}
