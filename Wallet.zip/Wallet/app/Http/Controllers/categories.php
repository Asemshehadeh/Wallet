<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\categorie;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class categories extends Controller
{    
    public function save(Request $req){

        $categorie = new categorie();
        $categorie['cat_name'] =  $req->input('cat_name'); 
        $categorie['cat_type'] =  $req->input('cat_type');
        $categorie['user_id'] = Auth::user()->id ;
        $categorie->save();
        return view('home');
    }
}
