<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        if(Auth::user()->role_id == 1){
        
            $users = DB::table('users')->get();
            $total=array();

            foreach ($users as $user){                                                    

                    $data['income'] = DB::table('categories')->where('cat_type','=', 'Income')->get('cat_id');            
                    
                    $id = $user->id;
                    $income_id=array();                    
                    foreach ($data['income'] as $item){                                
                        $income_id[]=$item->cat_id;
                    }

                    $data['tran_income'] = DB::table('user_transactions')           
                                            ->where(function ($query)  use ($income_id,$id) {
                                            $query->where('user_id_f', '=', $id)
                                            ->whereIntegerInRaw('cat_id_f', $income_id);
                                        })->get();
                                        
                    $total_income=0;
                    foreach ($data['tran_income'] as $tran_income_item){                
                        $total_income+=$tran_income_item->amount;
                    }
                    
                    $data['expenses'] = DB::table('categories')->where('cat_type','=', 'Expenses')->get('cat_id');

                    $expenses_id=array();
                    foreach ($data['expenses'] as $item_expenses){
                        $expenses_id[]=$item_expenses->cat_id;
                    }

                    $data['tra_exp'] = DB::table('user_transactions')           
                                            ->where(function ($query)  use ($expenses_id,$id) {
                                            $query->where('user_id_f', '=', $id)
                                            ->whereIntegerInRaw('cat_id_f', $expenses_id);
                                        })->get();
                                        
                    $total_expenses=0;
                    foreach ($data['tra_exp'] as $exp_income_item){                
                        $total_expenses+=$exp_income_item->amount;
                    }

                    $total[$user->id]['total_expenses']  =  $total_expenses;
                    $total[$user->id]['total_income'] = $total_income;
           
            }//end user loop            

            return view('home',compact('users','total'));
        }        
        return view('home');
    }

    public function Categorieslist(){
        $categories = DB::table('categories')->where('user_id','=', Auth::user()->id )->get();        
        return view('categoryview',compact('categories'));
    }

    public function transactionlist(){

            $all_trans = DB::table('user_transactions')->where('user_id_f','=', Auth::user()->id )->get();
            $total=array();
            $category_name=array();

            foreach ($all_trans as $tran){                                                    

                    $data['income'] = DB::table('categories')->where('cat_type','=', 'Income')->get('cat_id');            
                    
                    $id = Auth::user()->id;
                    $income_id=array();                    
                    foreach ($data['income'] as $item){                                
                        $income_id[]=$item->cat_id;
                    }

                    $data['tran_income'] = DB::table('user_transactions')           
                                            ->where(function ($query)  use ($income_id,$id) {
                                            $query->where('user_id_f', '=', $id)
                                            ->whereIntegerInRaw('cat_id_f', $income_id);
                                        })->get();
                                        
                    $total_income=0;
                    foreach ($data['tran_income'] as $tran_income_item){                
                        $total_income+=$tran_income_item->amount;
                    }
                    
                    $data['expenses'] = DB::table('categories')->where('cat_type','=', 'Expenses')->get('cat_id');

                    $expenses_id=array();
                    foreach ($data['expenses'] as $item_expenses){
                        $expenses_id[]=$item_expenses->cat_id;
                    }

                    $data['tra_exp'] = DB::table('user_transactions')           
                                            ->where(function ($query)  use ($expenses_id,$id) {
                                            $query->where('user_id_f', '=', $id)
                                            ->whereIntegerInRaw('cat_id_f', $expenses_id);
                                        })->get();
                                        
                    $total_expenses=0;
                    foreach ($data['tra_exp'] as $exp_income_item){                
                        $total_expenses+=$exp_income_item->amount;
                    }

                    $total['total_expenses']  =  $total_expenses;
                    $total['total_income'] = $total_income;

                    $category_name[$tran->tran_id]['cat_name'] = DB::table('categories')->where('cat_id','=', $tran->cat_id_f)->get('cat_name');
                    
            }            
            return view('transactions',compact('total','all_trans','category_name'));
    }

    public function UserCategorieslist(){
        $categories = DB::table('categories')->where('user_id','=', Auth::user()->id )->get();        
        return view('userview',compact('categories'));
    }
}
