<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

use App\Models\User;
use Carbon\Carbon;


class ChartJsController extends Controller

{

    public function index()

    {


        $all_trans = DB::table('user_transactions')->where('user_id_f','=', Auth::user()->id )->get();
            $total=array();
            $category_name=array();

            foreach ($all_trans as $tran){                                                    

                    $data['income'] = DB::table('categories')->where('cat_type','=', 'Income')->get('cat_id');            
                    
                    $id = Auth::user()->id;
                    $income_id=array();                    
                    foreach ($data['income'] as $item){                                
                        $income_id[]=$item->cat_id;
                    }

                    $data['tran_income'] = DB::table('user_transactions')           
                                            ->where(function ($query)  use ($income_id,$id) {
                                            $query->where('user_id_f', '=', $id)
                                            ->whereIntegerInRaw('cat_id_f', $income_id);
                                        })->get();
                                        
                    $total_income=0;
                    foreach ($data['tran_income'] as $tran_income_item){                
                        $total_income+=$tran_income_item->amount;
                    }
                    
                    $data['expenses'] = DB::table('categories')->where('cat_type','=', 'Expenses')->get('cat_id');

                    $expenses_id=array();
                    foreach ($data['expenses'] as $item_expenses){
                        $expenses_id[]=$item_expenses->cat_id;
                    }

                    $data['tra_exp'] = DB::table('user_transactions')           
                                            ->where(function ($query)  use ($expenses_id,$id) {
                                            $query->where('user_id_f', '=', $id)
                                            ->whereIntegerInRaw('cat_id_f', $expenses_id);
                                        })->get();
                                        
                    $total_expenses=0;
                    foreach ($data['tra_exp'] as $exp_income_item){                
                        $total_expenses+=$exp_income_item->amount;
                    }

                    $user[]  =  $total_expenses;
                    $user[] = $total_income;

                    $category_name[$tran->tran_id]['cat_name'] = DB::table('categories')->where('cat_id','=', $tran->cat_id_f)->get('cat_name');
                    
            }
        $year = ['2015','2016','2017','2018','2019','2020'];


    	return view('chartjs')->with('year',json_encode($year,JSON_NUMERIC_CHECK))->with('user',json_encode($user,JSON_NUMERIC_CHECK));

    }

}

