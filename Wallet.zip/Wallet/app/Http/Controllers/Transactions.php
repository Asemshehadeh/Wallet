<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User_Transactions;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class Transactions extends Controller
{
    //
    public function save(Request $req){
        $user_transactions = new User_Transactions();
        $user_transactions['cat_id_f'] =  $req->input('cat_id');
        $user_transactions['user_id_f'] =  Auth::user()->id ;
        $user_transactions['amount'] = $req->input('amount');;
        $user_transactions->save();        
        return view('home');
    }
}
