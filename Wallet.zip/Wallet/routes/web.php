<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/translist', [App\Http\Controllers\HomeController::class, 'transactionlist'])->name('translist');
Route::get('/catlist', [App\Http\Controllers\HomeController::class, 'UserCategorieslist'])->name('catlist');
Route::get('/category', [App\Http\Controllers\HomeController::class, 'Categorieslist'])->name('category');



//Route::view('/form','userview');
Route::view('/form','userview');
Route::post('/submit','App\Http\Controllers\Transactions@save');


//Route::view('/category','categoryview');
Route::post('/submitcat','App\Http\Controllers\categories@save');

use App\Http\Controllers\ChartJsController;
Route::get('chartjs', [ChartJsController::class, 'index'])->name('chartjs.index');